package com.example.Projectpandi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Bayar2 extends AppCompatActivity {
    private EditText EditNama, EditNis, EditKelas, EditTanggal, EditNominal;
    private Button btnBayar;
    private ProgressDialog progressDialog;
    private DatePickerDialog.OnDateSetListener setListener;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bayar2);
        EditNama        = findViewById(R.id.nama1);
        EditNis         = findViewById(R.id.nis1);
        EditKelas       = findViewById(R.id.kelas1);
        EditTanggal     = findViewById(R.id.tanggal1);
        EditNominal     = findViewById(R.id.nominal1);
        btnBayar        = findViewById(R.id.btntransaksi);

        progressDialog= new ProgressDialog(Bayar2.this);
        progressDialog.setTitle("loading");
        progressDialog.setTitle("Membayar...");
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month= calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        EditTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        Bayar2.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                month = month + 1;
                                String date = day+"/"+month+"/"+year;
                                EditTanggal.setText(date);
                            }
                            }, year, month, day);
                datePickerDialog.show();
            }
        });
        btnBayar.setOnClickListener(v -> {
            if (EditNama.getText().length() > 0 && EditNis.getText().length() > 0 && EditKelas.getText().length() > 0 && EditTanggal.getText().length() > 0 && EditNominal.getText().length() > 0) {
                bayarData(EditNama.getText().toString(), EditNis.getText().toString(), EditKelas.getText().toString(), EditTanggal.getText().toString(), EditNominal.getText().toString());
            } else {
                Toast.makeText(getApplicationContext(), "Silahkan Isi Semua Data!", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void bayarData(String nama, String nis, String kelas, String tanggal, String nominal) {
        Map<String, Object> user = new HashMap<>();
        user.put("nama", nama);
        user.put("nis", nis);
        user.put("kelas", kelas);
        user.put("tanggal", tanggal);
        user.put("nominal", nominal);

        progressDialog.show();
        db.collection("pendaftaran")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                });

            }

    }



