package com.example.Projectpandi.Model;

public class Siswa {
    private String id, namasiswa, nissiswa, jeniskelamin, alamatsiswa;

    public Siswa(){
    }
    public Siswa(String namasiswa, String nissiswa, String jeniskelamin, String alamatsiswa){
        this.namasiswa = namasiswa;
        this.nissiswa = nissiswa;
        this.jeniskelamin = jeniskelamin;
        this.alamatsiswa = alamatsiswa;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamasiswa() {
        return namasiswa;
    }

    public void setNamasiswa(String namasiswa) {
        this.namasiswa = namasiswa;
    }

    public String getNissiswa() {
        return nissiswa;
    }

    public void setNissiswa(String nissiswa) {
        this.nissiswa = nissiswa;
    }

    public String getJeniskelamin() {
        return jeniskelamin;
    }

    public void setJeniskelamin(String jeniskelamin) {
        this.jeniskelamin = jeniskelamin;
    }

    public String getAlamatsiswa() {
        return alamatsiswa;
    }

    public void setAlamatsiswa(String alamatsiswa) {
        this.alamatsiswa = alamatsiswa;
    }
}