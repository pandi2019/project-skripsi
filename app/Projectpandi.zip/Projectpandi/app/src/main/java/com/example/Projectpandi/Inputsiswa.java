package com.example.Projectpandi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Inputsiswa extends AppCompatActivity {
    private EditText editNama2, editNis2, editAlamat2;
    private Button btnSave;
    RadioGroup editJenis2;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inputsiswa);
        editNama2 = findViewById(R.id.nama_siswa);
        editNis2 = findViewById(R.id.nis_siswa);
        editJenis2 = (RadioGroup) findViewById(R.id.jeniskelamin);
        editAlamat2 = findViewById(R.id.alamat_siswa);
        btnSave = findViewById(R.id.btnsimpan);

        progressDialog = new ProgressDialog(Inputsiswa.this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Simpan...");

        btnSave.setOnClickListener(v -> {
            if (editNama2.getText().length() > 0 && editNis2.getText().length() > 0 && editJenis2.toString().length() > 0 && editAlamat2.getText().length() > 0) {
                saveData1(editNama2.getText().toString(), editNis2.getText().toString(), editJenis2.toString(), editAlamat2.getText().toString());

            } else {
                Toast.makeText(getApplicationContext(), "Silahkan isi semua data!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveData1(String namasiswa, String nissiswa, String jeniskelamin, String alamatsiswa){
        Map<String, Object> daftar = new HashMap<>();
        daftar.put("namasiswa", namasiswa);
        daftar.put("nissiswa", nissiswa);
        daftar.put("jeniskelamin", jeniskelamin);
        daftar.put("alamatsiswa", alamatsiswa);

        progressDialog.show();
            db.collection("siswa")
                    .add(daftar)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Toast.makeText(getApplicationContext(), "Berhasil!", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                            finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    });
        }
    }
