package com.example.Projectpandi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

public class Jadwal1 extends AppCompatActivity {
    private ImageButton btnPaud, btnPaketA, btnPaketB, btnPaketC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jadwal1);
        btnPaud        = findViewById(R.id.btnpaud);
        btnPaketA      = findViewById(R.id.btnpaketa);
        btnPaketB      = findViewById(R.id.btnpaketb);
        btnPaketC      = findViewById(R.id.btnpaketc);

        btnPaud.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), PaudJadwal.class));
        });

    }
}