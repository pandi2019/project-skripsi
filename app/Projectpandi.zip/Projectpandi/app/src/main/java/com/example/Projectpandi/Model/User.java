package com.example.Projectpandi.Model;

public class User {
    private String id, nama, nis, kelas, tanggal, nominal;

    public User(){

    }
    public User(String nama, String nis, String kelas, String tanggal, String nominal){
        this.nama = nama;
        this.nis = nis;
        this.kelas = kelas;
        this.tanggal = tanggal;
        this.nominal = nominal;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNis() {
        return nis;
    }

    public void setNis(String nis) {
        this.nis = nis;
    }

    public String getKelas() {
        return kelas;
    }

    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getNominal() {
        return nominal;
    }

    public void setNominal(String nominal) {
        this.nominal = nominal;
    }
}
