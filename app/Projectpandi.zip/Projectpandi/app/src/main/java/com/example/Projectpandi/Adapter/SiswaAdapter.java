package com.example.Projectpandi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Projectpandi.Model.Siswa;
import com.example.Projectpandi.R;

import java.util.List;

public class SiswaAdapter extends RecyclerView.Adapter<SiswaAdapter.myViewHolder> {
    private Context context;
    private List<Siswa> list;
    private Dialog dialog;

    public interface Dialog {
        void onClick(int pos);

    }

    public void setDialog(SiswaAdapter.Dialog dialog) {
        this.dialog = dialog;
    }

    public SiswaAdapter(Context context, List<Siswa> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public SiswaAdapter.myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_a, parent, false);
        return new SiswaAdapter.myViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        holder.namasiswa.setText(list.get(position).getNamasiswa());
        holder.nissiswa.setText(list.get(position).getNissiswa());
        holder.jeniskelamin.setText(list.get(position).getJeniskelamin());
        holder.alamatsiswa.setText(list.get(position).getAlamatsiswa());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class myViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        TextView namasiswa, nissiswa, jeniskelamin, alamatsiswa;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            namasiswa = itemView.findViewById(R.id.namasiswa);
            nissiswa = itemView.findViewById(R.id.nissiswa);
            jeniskelamin = itemView.findViewById(R.id.jeniskelamin);
            alamatsiswa = itemView.findViewById(R.id.alamatsiswa);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (dialog != null) {
                        dialog.onClick(getLayoutPosition());
                    }
                }
            });
        }
    }
}