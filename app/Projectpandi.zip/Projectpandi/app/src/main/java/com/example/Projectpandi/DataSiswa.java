package com.example.Projectpandi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.Projectpandi.Adapter.SiswaAdapter;
import com.example.Projectpandi.Model.Siswa;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class DataSiswa extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FloatingActionButton btnAdd10;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private List<Siswa> list = new ArrayList<>();
    private SiswaAdapter siswaAdapter;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_siswa);
        recyclerView = findViewById(R.id.tampil);
        btnAdd10 = findViewById(R.id.btnadd3);

        progressDialog = new ProgressDialog(DataSiswa.this);
        progressDialog.setTitle("loading");
        progressDialog.setMessage("Mengambil Data...");
        siswaAdapter = new SiswaAdapter(getApplicationContext(),list);
        siswaAdapter.setDialog(new SiswaAdapter.Dialog(){

            @Override
            public void onClick(int pos){
                final CharSequence[] dialogItem = {"Edit","Hapus"};
                AlertDialog.Builder dialog = new AlertDialog.Builder( DataSiswa.this);
                dialog.setItems(dialogItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i){
                            case 0:
                                Intent intent = new Intent(getApplicationContext(), Inputsiswa.class);
                                intent.putExtra("id", list.get(pos).getId());
                                intent.putExtra("namasiswa", list.get(pos).getNamasiswa());
                                intent.putExtra("nissiswa", list.get(pos).getNissiswa());
                                intent.putExtra("jeniskelamin", list.get(pos).getJeniskelamin());
                                intent.putExtra("alamatsiswa", list.get(pos).getAlamatsiswa());
                                startActivity(intent);
                                break;
                            case 1:
                                deleteData(list.get(pos).getId());
                                break;
                        }
                    }
                });
                dialog.show();
            }
        });

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        RecyclerView.ItemDecoration decoration = new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(decoration);
        recyclerView.setAdapter(siswaAdapter);



        btnAdd10.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), Inputsiswa.class));
        });
        getData();
    }

    private void getData(){
        progressDialog.show();
        db.collection("siswa")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>(){
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot>task){
                        list.clear();
                        if(task.isSuccessful()){
                            for (QueryDocumentSnapshot document:task.getResult()){
                                Siswa daftar = new Siswa(document.getString("namasiswa"), document.getString("nissiswa"), document.getString("jeniskelamin"), document.getString("alamatsiswa"));
                                daftar.setId(document.getId());
                                list.add(daftar);
                            }
                            siswaAdapter.notifyDataSetChanged();
                        }else {
                            Toast.makeText(getApplicationContext(), "Data Gagal Tampil", Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }
                });

    }
    private void deleteData(String id){
        progressDialog.show();
        db.collection("daftar").document(id)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Data Gagal Dihapus!", Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                        getData();
                    }
                });
    }

}